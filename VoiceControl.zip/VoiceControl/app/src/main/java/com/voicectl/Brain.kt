package com.voicectl

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.KeyEvent
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** «Мозг»: разбирает фразу на команды и выполняет их. */
object Brain {
    val logs = CopyOnWriteArrayList<String>()
    @Volatile var running = false
    @Volatile var onLog: (() -> Unit)? = null
    private val ex = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    fun log(m: String) { logs.add(m); while (logs.size > 25) logs.removeAt(0); ui.post { onLog?.invoke() } }
    fun norm(s: String) = s.lowercase().replace('ё', 'е').replace(Regex("[\"«»“”„]"), "").trim()
    fun names(c: Context) = (c.getSharedPreferences("vc", 0).getString("names", "джарвис") ?: "джарвис")
        .split(",").map { norm(it) }.filter { it.isNotEmpty() }

    private const val VERBS = "открой|открыть|запусти|зайди|войди|выйди|включи|введи|набери|напиши|отправь|нажми|найди|закрой|назад|домой|прокрути|пролистай|листай|стоп|пауза|продолжай|разблокируй|заблокируй|громче|тише|скриншот|вернись|выбери|кликни|очисти|перейди|сверни|вниз|вверх|следующее"

    private val DW = mapOf("ноль" to "0", "один" to "1", "два" to "2", "три" to "3", "четыре" to "4",
        "пять" to "5", "шесть" to "6", "семь" to "7", "восемь" to "8", "девять" to "9")
    private fun digits(s: String) = s.split(" ").joinToString("") { DW[it] ?: it }.filter { it.isDigit() }

    private val AL = listOf("ютуб|ютьюб" to "youtube", "телеграм+" to "telegram", "вацап|ватсап|вотсап|ватцап" to "whatsapp",
        "вайбер" to "viber", "хром|браузер" to "chrome", "инстаграм+" to "instagram", "тикток|тик ток" to "tiktok",
        "вк|вконтакте" to "vk", "гугл" to "google", "карты" to "maps", "почта" to "gmail",
        "плей маркет|гугл плей|магазин приложений" to "play", "нетфликс" to "netflix", "спотифай" to "spotify",
        "дискорд" to "discord", "твитч" to "twitch", "настройки" to "settings", "камера" to "camera",
        "галерея|фото" to "photos", "калькулятор" to "calculator", "часы|будильник" to "clock",
        "контакты" to "contacts", "телефон" to "phone", "сообщения" to "messages", "файлы" to "files",
        "музыка" to "music", "яндекс" to "yandex")

    fun go(c: Context, text: String) = ex.execute {
        log("▶ $text")
        val parts = text.split(Regex("\\s+(?:и|потом|затем|после этого|а потом)\\s+(?=(?:$VERBS)(?:\\s|$))"))
        for (p in parts) {
            try { exec(c, p.trim()) } catch (e: Exception) { log("✖ Ошибка: ${e.message}") }
            Thread.sleep(1200)
        }
    }

    @Suppress("DEPRECATION")
    fun wake(c: Context) {
        c.getSystemService(PowerManager::class.java).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "voicectl:wake").acquire(8000)
    }

    private fun media(am: AudioManager, k: Int) {
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
    }

    private fun vol(am: AudioManager, dir: Int) {
        repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, if (it == 2) AudioManager.FLAG_SHOW_UI else 0) }
    }

    private fun openApp(c: Context, a: ControlService?, name: String) {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString().lowercase().replace('ё', 'е') to it.activityInfo.packageName }
        val keys = mutableListOf(name)
        AL.forEach { if (Regex(it.first).matches(name)) keys.add(it.second) }
        var pkg: String? = null
        for (k in keys) {
            pkg = apps.firstOrNull { it.first == k }?.second ?: apps.firstOrNull { it.first.contains(k) }?.second
            if (pkg != null) break
        }
        if (pkg == null) return log("✖ Не нашёл приложение «$name»")
        val i = pm.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return log("✖ Нельзя запустить «$name»")
        (a ?: c).startActivity(i)
        log("✔ Открываю $name")
    }

    private fun exec(c: Context, s: String) {
        val a = ControlService.inst
        fun f(p: String) = Regex(p).find(s)?.groupValues
        fun t(p: String) = Regex(p).matches(s)
        fun has(p: String) = Regex(p).containsMatchIn(s)
        fun acc(b: (ControlService) -> Unit) { if (a == null) log("⚠ Включи службу доступности") else b(a) }
        fun ok(m: String) = log("✔ $m")
        val am = c.getSystemService(AudioManager::class.java)
        val G = AccessibilityService::class.java

        // --- экран, замок ---
        if (t("(?:(?:включи|разбуди|активируй|зажги) (?:планшет|телефон|экран|устройство))|проснись|разбуди")) { wake(c); return ok("Экран включён") }
        if (t("выключись|отключись|завершить работу|прекрати слушать|спи")) { c.stopService(Intent(c, VoiceService::class.java)); return }
        if (s.startsWith("разблок") || s.startsWith("сними блокировку") || has("^(?:введи |набери )?(?:пароль|пин|код)")) {
            val d = digits(s).ifEmpty { c.getSharedPreferences("vc", 0).getString("pin", "") ?: "" }
            wake(c); Thread.sleep(800)
            return acc { it.unlock(d); ok("Разблокировка") }
        }
        if (t("(?:заблокируй|выключи)(?: (?:экран|планшет|телефон|устройство))?|усни"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); ok("Экран заблокирован") }

        // --- медиа и звук ---
        if (has("^(?:стоп|пауз|стой|хватит|останови|замри|поставь на пауз)")) { media(am, KeyEvent.KEYCODE_MEDIA_PAUSE); return ok("Пауза") }
        if (has("^(?:продолж|играй|воспроизв|плей|снова|давай дальше|включи видео|запусти видео)")) { media(am, KeyEvent.KEYCODE_MEDIA_PLAY); return ok("Продолжаю") }
        if (has("^следующ")) { media(am, KeyEvent.KEYCODE_MEDIA_NEXT); return ok("Следующее") }
        if (has("^предыдущ")) { media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS); return ok("Предыдущее") }
        if (has("^(?:громче|погромче|прибавь)")) { vol(am, AudioManager.ADJUST_RAISE); return ok("Громче") }
        if (has("^(?:тише|потише|убавь)")) { vol(am, AudioManager.ADJUST_LOWER); return ok("Тише") }
        if (t("без звука|выключи звук|убери звук")) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); return ok("Без звука") }

        // --- навигация ---
        if (t("домой|на главный.*|главный экран|рабочий стол|на рабочий стол|выйди.*|выйти.*|выход.*|закрой.*|сверни.*"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); ok("Домой") }
        if (t("назад|вернись.*|вернуться.*|шаг назад"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); ok("Назад") }
        if (t("недавние.*|последние приложения|переключи приложени.*|покажи приложения|многозадачность"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS); ok("Недавние") }
        if (t("(?:покажи |открой )?(?:уведомления|шторк\\S*)"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); ok("Шторка") }
        if (t("(?:открой )?быстрые настройки"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS); ok("Быстрые настройки") }
        if (t("(?:сделай )?(?:скриншот|снимок экрана)"))
            return acc { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT); ok("Скриншот") }
        f("^(?:(?:прокрути|пролистай|листай|свайпни|свайп|скролл|двигай) )?(вниз|вверх|влево|вправо)$")?.let { g ->
            return acc { it.scroll(g[1]); ok("Прокрутка ${g[1]}") }
        }

        // --- результаты, чаты, поиск ---
        if (has("^(?:(?:включи|открой|выбери|нажми на|запусти|зайди в|давай) )?(?:самое |самый )?перв\\S*"))
            return acc { it.firstResult(); ok("Первый результат") }
        f("^(?:открой|зайди|войди|перейди|найди)(?: в| к| на)? (?:чат|диалог|переписку|беседу) (?:с |со |у )?(.+)")?.let { g ->
            return acc { if (it.openChat(g[1])) ok("Чат: ${g[1]}") else log("✖ Не нашёл чат «${g[1]}»") }
        }
        (f("^(?:введи|набери|напиши|вбей|впиши|найди|ищи|поищи) (?:в )?(?:поиске|поиск|поисковой строке|строке поиска|поле поиска|поисковике)(?: по)? (.+)")
            ?: f("^(?:найди|ищи|поищи|поиск|вбей в поиск) (.+)"))?.let { g ->
            return acc { if (it.search(g[1])) ok("Поиск: ${g[1]}") else log("✖ Не нашёл поле поиска") }
        }

        // --- ввод текста ---
        if (t("(?:отправь|отправить|отправляй|шли|жми отправить|нажми отправить)(?: сообщение)?"))
            return acc { if (it.clickAny("отправить", "send") || it.enter()) ok("Отправлено") else log("✖ Кнопка отправки не найдена") }
        if (has("^(?:очисти|сотри|удали) (?:текст|поле|строку)")) return acc { it.setText("", false); ok("Очищено") }
        f("^(?:допиши|добавь) (.+)")?.let { g -> return acc { it.setText(g[1], true); ok("Дописано") } }
        f("^(?:напиши|набери|введи|впиши|напечатай)(?: (?:сообщение|текст|ответ))? (.+)")?.let { g ->
            return acc { if (it.setText(g[1].replaceFirstChar { ch -> ch.uppercase() }, false)) ok("Текст введён") else log("✖ Нет поля ввода") }
        }
        f("^(?:нажми|кликни|тапни|выбери|нажать)(?: на)? (.+)")?.let { g ->
            return acc { if (it.clickText(g[1])) ok("Нажал: ${g[1]}") else log("✖ Не вижу «${g[1]}»") }
        }

        // --- приложения ---
        f("^(?:открой|открыть|запусти|запустить|зайди в|зайди на|зайди|войди в|включи|перейди в|перейди на|давай)(?: приложение)? (.+)")?.let { g ->
            return openApp(c, a, g[1])
        }
        log("❓ Не понял: $s")
    }
}
