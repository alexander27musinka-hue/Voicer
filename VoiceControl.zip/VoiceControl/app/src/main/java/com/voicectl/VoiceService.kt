package com.voicectl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** «Уши»: постоянно слушает микрофон, ждёт имя бота и передаёт команду в Brain. */
class VoiceService : Service() {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var armed = 0L
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("vc", "Голосовое управление", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "vc").setContentTitle("Голосовое управление")
            .setContentText("Слушаю: имя бота + команда").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Brain.log("✖ На устройстве нет службы распознавания речи (Google)"); stopSelf(); return START_NOT_STICKY }
        if (!Brain.running) {
            Brain.running = true
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicectl:listen").apply { acquire() }
            Brain.log("🎧 Слушаю. Имя бота: " + Brain.names(this).joinToString(", "))
            listen()
        }
        return START_STICKY
    }

    private fun listen() {
        if (!Brain.running) return
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { Brain.log("✖ Нет разрешения на микрофон"); stopSelf(); return }
                h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 200L else 1500L)
            }
            override fun onResults(res: Bundle?) {
                res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.let { handle(it) }
                h.postDelayed({ listen() }, 200)
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3))
    }

    private fun handle(l: List<String>) {
        val ns = Brain.names(this)
        for (t in l) {
            val s = Brain.norm(t)
            for (n in ns) {
                val i = s.indexOf(n)
                if (i >= 0) {
                    val cmd = s.substring(i + n.length).trim(' ', ',', '.', '!')
                    if (cmd.isEmpty()) { armed = SystemClock.elapsedRealtime() + 10000; Brain.log("👂 Слушаю команду…") }
                    else Brain.go(this, cmd)
                    return
                }
            }
        }
        if (SystemClock.elapsedRealtime() < armed && l.isNotEmpty()) { armed = 0; Brain.go(this, Brain.norm(l[0])) }
    }

    override fun onDestroy() {
        Brain.running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        wl?.let { if (it.isHeld) it.release() }
        Brain.log("⏹ Остановлено")
        super.onDestroy()
    }
}
