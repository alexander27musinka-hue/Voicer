package com.voicectl

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** «Руки» бота: нажимает, вводит текст, листает, разблокирует. */
class ControlService : AccessibilityService() {
    companion object { @Volatile var inst: ControlService? = null }

    override fun onServiceConnected() { inst = this; Brain.log("✔ Служба доступности подключена") }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val w: Float get() = resources.displayMetrics.widthPixels.toFloat()
    private val h: Float get() = resources.displayMetrics.heightPixels.toFloat()

    // ---------- поиск элементов ----------
    fun nodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo, d: Int) {
            out.add(n)
            if (d < 40) for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, d + 1) }
        }
        val ws = try { windows.mapNotNull { it.root } } catch (_: Exception) { emptyList() }
        (if (ws.isNotEmpty()) ws else listOfNotNull(rootInActiveWindow)).forEach { walk(it, 0) }
        return out
    }

    private fun hit(n: AccessibilityNodeInfo, t: String, exact: Boolean): Boolean {
        val a = (n.text?.toString() ?: "").lowercase().replace('ё', 'е')
        val b = (n.contentDescription?.toString() ?: "").lowercase().replace('ё', 'е')
        return if (exact) a.trim() == t || b.trim() == t else a.contains(t) || b.contains(t)
    }

    fun find(t: String, exact: Boolean = false) =
        nodes().firstOrNull { it.isVisibleToUser && !it.isEditable && hit(it, t, exact) }

    fun clickText(t: String, exact: Boolean = false): Boolean {
        val n = find(t, exact) ?: return false
        return click(n)
    }

    fun clickAny(vararg ts: String): Boolean {
        for (t in ts) if (clickText(t)) return true
        return false
    }

    // ---------- действия ----------
    fun click(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
        }
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long = 300): Boolean {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float) = gesture(x, y, x, y, 50)

    fun scroll(dir: String) {
        val cx = w / 2; val cy = h / 2
        when (dir) {
            "вниз" -> gesture(cx, h * .75f, cx, h * .25f)
            "вверх" -> gesture(cx, h * .25f, cx, h * .75f)
            "влево" -> gesture(w * .8f, cy, w * .2f, cy)
            else -> gesture(w * .2f, cy, w * .8f, cy)
        }
    }

    fun editField(): AccessibilityNodeInfo? {
        val all = nodes()
        for (n in all) if (n.isFocused && n.isEditable) return n
        return all.firstOrNull { it.isEditable && it.isVisibleToUser }
    }

    fun setText(t: String, append: Boolean): Boolean {
        val f = editField() ?: return false
        val old = if (append && !f.isShowingHintText) f.text?.toString() ?: "" else ""
        val txt = if (old.isNotEmpty()) "$old $t" else t
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun enter(): Boolean {
        if (Build.VERSION.SDK_INT >= 30) {
            val f = editField()
            if (f != null && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
        }
        return clickAny("search", "поиск", "найти", "go")
    }

    fun search(q: String): Boolean {
        if (editField() == null) { clickAny("поиск", "search", "найти"); Thread.sleep(1000) }
        if (!setText(q, false)) return false
        Thread.sleep(500); enter(); return true
    }

    /** Первый результат (видео / строка списка) под строкой поиска. */
    fun firstResult(): Boolean {
        Thread.sleep(1200)
        val best = nodes().filter { it.isVisibleToUser && it.isClickable }
            .map { n -> Rect().also { n.getBoundsInScreen(it) }.let { n to it } }
            .filter { (_, r) -> r.top >= h * .15f && r.height() > h * .05f && r.width() > w * .5f }
            .minByOrNull { it.second.top }
        return if (best != null) click(best.first) else tap(w / 2, h * .35f)
    }

    fun openChat(name: String): Boolean {
        if (clickText(name)) return true
        clickAny("поиск", "search"); Thread.sleep(900)
        if (!setText(name, false)) return false
        Thread.sleep(1500)
        return clickText(name) || firstResult()
    }

    fun unlock(pin: String) {
        gesture(w / 2, h * .85f, w / 2, h * .25f, 250); Thread.sleep(1000)
        for (d in pin) { find(d.toString(), true)?.let { click(it) }; Thread.sleep(180) }
        if (pin.isNotEmpty()) { Thread.sleep(250); clickAny("enter", "ввод") }
    }
}
